export const PORT = 5555;
export const mongoDBURL = 'mongodb+srv://atubak40:vqKwfvS1gDHnJJuj@book-store.xqtbk9k.mongodb.net/?retryWrites=true&w=majority'
